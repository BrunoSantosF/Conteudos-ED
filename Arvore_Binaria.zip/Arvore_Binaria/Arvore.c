#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Aluno.h"
#include "Arvore.h"

struct arvore {
    tAluno * aluno;
    tArvore * esquerda;
    tArvore * direita;
};

tArvore * CriaArvoreVazia(){
    return NULL;
}

tArvore * InsereNaArvore(tArvore * arvore,tAluno * aluno){
    
    if(arvore == NULL){
        arvore = malloc(sizeof(tArvore));
        arvore->aluno = aluno;
        arvore->direita = arvore->esquerda = NULL;
    }
    else if (RetornaId(arvore->aluno) < RetornaId(aluno)){
        arvore->direita = InsereNaArvore(arvore->direita,aluno);
    }
    else {
        arvore->esquerda = InsereNaArvore(arvore->esquerda,aluno);
    }

    return arvore;
}

void ImprimiAlunoEncontrado(tArvore * arvore){
    printf("\033[36;1mO aluno encontrado eh: %s \033[m\n",RetornaNome(arvore->aluno));
}

tArvore * BuscaArvore(tArvore * arvore,int aluno){

    if (arvore == NULL){
        return NULL;
    }
    if (RetornaId(arvore->aluno) == aluno){
        return arvore;
    }
    else if (RetornaId(arvore->aluno) < aluno){
        arvore->direita = BuscaArvore(arvore->direita, aluno);
    }
    else {
        arvore->esquerda = BuscaArvore(arvore->esquerda,aluno);
    }

}

tArvore * RetiraArvore(tArvore * arvore,int id){
    tArvore * arv = NULL;

    if (arvore == NULL){
        return NULL;
    }
    else if (RetornaId(arvore->aluno) < id){
        arvore->direita = RetiraArvore(arvore->direita,id);
    }
    else if (RetornaId(arvore->aluno) > id){
        arvore->esquerda = RetiraArvore(arvore->esquerda,id);
    }
    else {
        if (arvore->direita == NULL && arvore->esquerda == NULL){ // folhas da arvore
            RemoveAluno(arvore->aluno);
            free(arvore);
            return NULL;
        }
        else if (arvore->direita != NULL && arvore->esquerda == NULL){ // esquerda vazia
            arv = arvore->direita;
            RemoveAluno(arvore->aluno);
            free(arvore);
            return arv;
        }
        else if (arvore->direita == NULL && arvore->esquerda != NULL){ // direita vazia
            arv = arvore->esquerda;
            RemoveAluno(arvore->aluno);
            free(arvore);
            return arv;
        }
        else {
            arv = arvore->esquerda;
            while(arv->direita){
                arv = arv->direita;
            }
            tAluno * aluno = arvore->aluno;
            arvore->aluno = arv->aluno;
            arv->aluno = aluno;

            arvore->esquerda = RetiraArvore(arvore->esquerda,id);

        }

    }

    return arvore;


}

void ImprimiArvore(tArvore * arvore){
    if (arvore){
        ImprimiAluno(arvore->aluno);
        printf("\n\033[32;1m===== Esquerda ===== \033[m\n");
        ImprimiArvore(arvore->esquerda);
        printf("\n\033[33;1m===== Direita =====  \033[m\n");
        ImprimiArvore(arvore->direita);
    }
}


void RemoveArvore(tArvore * arvore){
    if (arvore){
        
        RemoveArvore(arvore->esquerda);
        RemoveArvore(arvore->direita);
        RemoveAluno(arvore->aluno);
        free(arvore);
    }
}
