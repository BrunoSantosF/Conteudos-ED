#ifndef ARVORE_H
#define ARVORE_H

typedef struct arvore tArvore;

tArvore * CriaArvoreVazia();

tArvore * InsereNaArvore(tArvore * arvore,tAluno * aluno);

tArvore * BuscaArvore(tArvore * arvore,int aluno);

void ImprimiArvore(tArvore * arvore);

void ImprimiAlunoEncontrado(tArvore * arvore);

void RemoveArvore(tArvore * arvore);

tArvore * RetiraArvore(tArvore * arvore,int id);
#endif