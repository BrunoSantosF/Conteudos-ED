#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Aluno.h"
#include "Arvore.h"


int main(){

    FILE * arquivo =  fopen("input.txt","r");
    char string[100],nome[30];
    int id = 0;


    tArvore * arvore = CriaArvoreVazia();
    while (!feof(arquivo)){
        fscanf(arquivo,"%[^\n]\n",string);
        sscanf(string,"%s %d",nome,&id);
        tAluno * aluno = CriaAluno(nome,id);
        arvore = InsereNaArvore(arvore,aluno);

    }
    fclose(arquivo);

    ImprimiArvore(arvore);
    //tArvore * arv =  BuscaArvore(arvore,22);
    //ImprimiAlunoEncontrado(arv);
    printf("\n------------------------------------\n");
    RetiraArvore(arvore,14);

    ImprimiArvore(arvore);
    
    RemoveArvore(arvore);


    return 0;
}